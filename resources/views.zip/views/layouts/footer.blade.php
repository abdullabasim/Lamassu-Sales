<!-- footer content -->
<footer>
    <div class="pull-right">
        {{date("Y")}} &copy; By Lemassu Co.
        </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->